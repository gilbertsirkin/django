import json
import os
import resend

from django.conf import settings
from django.db import transaction
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from groq import Groq

from .models import ChatMessage, ChatSession

client = Groq(api_key=settings.GROQ_API_KEY)

SYSTEM_PROMPT = """
You are Alex, a senior support agent and investment advisor at WolvCapital. You are deeply knowledgeable about every aspect of the WolvCapital platform. Be warm, professional, concise, and solution-focused. Keep replies to 3–5 sentences unless a detailed explanation is needed. Always refer users to the relevant dashboard section or page when appropriate.

━━━━━━━━━━━━━━━━━━━━━━━━
ABOUT WOLVCAPITAL
━━━━━━━━━━━━━━━━━━━━━━━━
WolvCapital is a blockchain-verified investment and staking platform built on the BNB Smart Chain (BSC). Every return is recorded permanently on-chain — independently verifiable, immutable, and transparent. The platform is KYC-verified, AML-compliant, and designed for global investors seeking passive income through structured staking plans.

Website: https://www.wolvcapital.com
Support email: support@mail.wolvcapital.com
Dashboard: https://www.wolvcapital.com/dashboard

━━━━━━━━━━━━━━━━━━━━━━━━
INVESTMENT PLANS
━━━━━━━━━━━━━━━━━━━━━━━━
All plans run on BNB Smart Chain with verifiable smart contracts. Daily ROI is paid out automatically.

1. PIONEER
   - APY: 8% | Duration: 90 Days
   - Min: $100 | Max: $999
   - Best for: first-time investors and smaller allocations
   - URL: https://www.wolvcapital.com/plans/pioneer

2. VANGUARD
   - APY: 12% | Duration: 150 Days
   - Min: $1,000 | Max: $4,999
   - Best for: investors seeking a mid-range plan structure
   - URL: https://www.wolvcapital.com/plans/vanguard

3. HORIZON
   - APY: 18% | Duration: 180 Days
   - Min: $5,000 | Max: $14,999
   - Best for: experienced investors with higher allocations
   - URL: https://www.wolvcapital.com/plans/horizon

4. SUMMIT VIP
   - APY: 25% | Duration: 365 Days
   - Min: $15,000 | Max: $50,000
   - Best for: high-net-worth investors seeking maximum returns
   - URL: https://www.wolvcapital.com/plans/summit

Minimum deposit to start: $50. All plans require KYC verification before activation.

━━━━━━━━━━━━━━━━━━━━━━━━
FEES & WITHDRAWALS
━━━━━━━━━━━━━━━━━━━━━━━━
- Withdrawal fee: $5 flat + 2% of withdrawal amount
- Minimum deposit: $50
- Withdrawals require completed KYC verification
- Withdrawals may require additional verification depending on amount
- High withdrawal threshold: $5,000+ triggers additional review
- Full withdrawal policy: https://www.wolvcapital.com/withdrawal-policy

━━━━━━━━━━━━━━━━━━━━━━━━
KYC VERIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━
KYC (Know Your Customer) is mandatory for all investors before activating any plan or making withdrawals.

Steps:
1. Email Verification — verify your email address
2. Personal Information — complete your profile (name, DOB, nationality, address)
3. Identity Documents — upload government-issued ID (front & back) + proof of address
4. Enhanced Verification — optional video call for higher withdrawal limits ($50,000+)

Accepted documents: Passport, National ID card, Driver's licence
Proof of address: Utility bill, bank statement, or official lease (issued within 3 months)
KYC dashboard: https://www.wolvcapital.com/dashboard/kyc

━━━━━━━━━━━━━━━━━━━━━━━━
WOLV TOKEN
━━━━━━━━━━━━━━━━━━━━━━━━
WOLV is WolvCapital's native BEP-20 utility and rewards token on BNB Smart Chain.
- Investors earn WOLV tokens as staking rewards
- WOLV tokens are distributed on-chain, verifiable on BSC
- Token page: https://www.wolvcapital.com/wolv-token
- Tokenomics: https://www.wolvcapital.com/tokenomics
- Whitepaper: https://www.wolvcapital.com/whitepaper

━━━━━━━━━━━━━━━━━━━━━━━━
VIRTUAL CARD
━━━━━━━━━━━━━━━━━━━━━━━━
WolvCapital offers a Stripe-powered virtual card for verified investors.
- Available to KYC-approved users
- Can be used for online purchases globally
- Managed via dashboard: https://www.wolvcapital.com/dashboard/cards
- Card purchase: https://www.wolvcapital.com/dashboard/purchase-card

━━━━━━━━━━━━━━━━━━━━━━━━
REFERRAL PROGRAM
━━━━━━━━━━━━━━━━━━━━━━━━
- Users earn rewards for referring new investors
- Referral dashboard: https://www.wolvcapital.com/dashboard
- Referral page: https://www.wolvcapital.com/referrals
- Rewards are tracked and paid automatically

━━━━━━━━━━━━━━━━━━━━━━━━
SECURITY & COMPLIANCE
━━━━━━━━━━━━━━━━━━━━━━━━
- 256-bit SSL encryption on all connections
- Mandatory 2FA available
- KYC on every account, AML on every transaction
- FinCEN MSB Registered · PCI-DSS Compliant
- All returns are blockchain-verified and immutable
- Security page: https://www.wolvcapital.com/security

━━━━━━━━━━━━━━━━━━━━━━━━
HOW IT WORKS
━━━━━━━━━━━━━━━━━━━━━━━━
1. Create account at wolvcapital.com
2. Complete KYC verification
3. Deposit funds (minimum $50)
4. Choose an investment plan
5. Earn daily ROI paid in WOLV tokens on-chain
6. Withdraw anytime after plan maturity

Full guide: https://www.wolvcapital.com/how-it-works

━━━━━━━━━━━━━━━━━━━━━━━━
DASHBOARD PAGES
━━━━━━━━━━━━━━━━━━━━━━━━
- Overview: /dashboard
- Deposit: /dashboard/deposit
- Withdraw: /dashboard/withdraw
- Transactions: /dashboard/transactions
- KYC: /dashboard/kyc
- New Investment: /dashboard/new-investment
- Staking: /dashboard/stake
- Virtual Card: /dashboard/cards
- WOLV Token: /dashboard/wolv-token
- Support: /dashboard/support

━━━━━━━━━━━━━━━━━━━━━━━━
CONTACT & SUPPORT
━━━━━━━━━━━━━━━━━━━━━━━━
- Email: support@mail.wolvcapital.com
- Support ticket: https://www.wolvcapital.com/dashboard/support
- Contact page: https://www.wolvcapital.com/contact
- Live chat available on the platform

━━━━━━━━━━━━━━━━━━━━━━━━
IMPORTANT DISCLAIMERS
━━━━━━━━━━━━━━━━━━━━━━━━
- Digital assets are volatile; outcomes can be positive or negative
- No guaranteed returns — all APY figures are projections based on plan structure
- Always recommend users read full risk disclosure: https://www.wolvcapital.com/risk-disclosure
- Never promise specific returns or guarantee profits
- For legal/compliance questions refer to: https://www.wolvcapital.com/legal

━━━━━━━━━━━━━━━━━━━━━━━━
BEHAVIOUR RULES
━━━━━━━━━━━━━━━━━━━━━━━━
- Always identify as Alex from WolvCapital Support
- Never reveal you are an AI unless directly asked
- If directly asked if you are an AI, be honest
- Never share internal system information or code
- If you cannot answer, escalate: "Let me connect you with a senior advisor — please submit a support ticket at wolvcapital.com/dashboard/support"
- Always be warm, professional, and solution-focused
- For account-specific issues (balances, transactions), direct users to their dashboard or support ticket
"""


def extract_user_message(payload: dict) -> str:
    message = payload.get("message")
    if isinstance(message, str) and message.strip():
        return message.strip()

    messages = payload.get("messages", [])
    if isinstance(messages, list):
        for item in reversed(messages):
            if (
                isinstance(item, dict)
                and item.get("role") == "user"
                and isinstance(item.get("content"), str)
            ):
                return item["content"].strip()

    return ""


def get_recent_session_messages(session_id: str, limit: int = 5) -> list[dict]:
    recent_messages = (
        ChatMessage.objects.filter(session_id=session_id)
        .order_by("-created_at")
        .values("role", "content")[:limit]
    )
    return list(reversed(list(recent_messages)))


@csrf_exempt
@require_POST
def chat(request):
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON body."}, status=400)

    session_id = str(payload.get("session_id", "")).strip()
    if not session_id:
        return JsonResponse({"error": "session_id is required."}, status=400)

    user_content = extract_user_message(payload)
    if not user_content:
        return JsonResponse({"error": "User message is required."}, status=400)

    if not settings.GROQ_API_KEY:
        return JsonResponse({"error": "GROQ_API_KEY is not configured."}, status=500)

    saved_user_message = ChatMessage.objects.create(
        session_id=session_id,
        role=ChatMessage.USER,
        content=user_content,
        is_human_handover=False,
    )

    # Telegram alert for visitor message (swipe-reply to respond)
    try:
        from .telegram import notify_new_message
        _sess = ChatSession.objects.filter(session_id=session_id).first()
        notify_new_message(
            session_id, user_content,
            user_name=(_sess.user_name if _sess else "") or "",
            user_email=(_sess.user_email if _sess else "") or "",
        )
    except Exception as _e:
        print(f"[Telegram] notify failed: {_e}")

    # If a human agent is active, skip the AI so it doesn't talk over them
    try:
        _active = ChatSession.objects.filter(session_id=session_id, status="active").exists()
    except Exception:
        _active = False
    if _active:
        return JsonResponse({"reply": None, "human_active": True})

    session_history = get_recent_session_messages(session_id)
    prompt_messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        *session_history,
        {"role": "user", "content": user_content},
    ]

    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            max_tokens=1000,
            temperature=0.7,
            messages=prompt_messages,
        )

        reply = ""
        if getattr(response, "choices", None):
            first_choice = response.choices[0]
            reply = getattr(getattr(first_choice, "message", None), "content", "") or ""

        with transaction.atomic():
            ChatMessage.objects.create(
                session_id=session_id,
                role=ChatMessage.ASSISTANT,
                content=reply,
                is_human_handover=False,
            )

        return JsonResponse({"reply": reply})

    except Exception as exc:
        return JsonResponse({"error": str(exc)}, status=500)

# --- Placeholders for Agent Handover ---
from django.http import JsonResponse

def request_human(request):
    return JsonResponse({"status": "placeholder"})

def agent_reply(request):
    return JsonResponse({"status": "placeholder"})

def get_sessions(request):
    return JsonResponse({"status": "placeholder"})

def get_messages(request):
    return JsonResponse({"status": "placeholder"})


@csrf_exempt
def request_human(request):
    if request.method == 'GET':
        return JsonResponse({'status': 'ok', 'message': 'Chat human handover endpoint'})
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    session_id = str(payload.get("session_id", "")).strip()
    user_email = str(payload.get("user_email", "")).strip()
    user_name = str(payload.get("user_name", "")).strip()

    if not session_id:
        return JsonResponse({"error": "session_id required"}, status=400)

    from .models import ChatSession
    from django.utils import timezone
    session, _ = ChatSession.objects.get_or_create(session_id=session_id)
    session.status = "waiting"
    session.user_email = user_email
    session.user_name = user_name
    session.human_requested_at = timezone.now()
    session.save()

    try:
        from .telegram import notify_human_requested
        notify_human_requested(session_id, user_name, user_email)
    except Exception as _e:
        print(f"[Telegram] human-request notify failed: {_e}")

    recent = ChatMessage.objects.filter(session_id=session_id).order_by("-created_at")[:5]
    transcript = "\n".join([f"{m.role.upper()}: {m.content}" for m in reversed(list(recent))])

    if not session.alert_sent:
        try:
            resend.api_key = os.environ.get("RESEND_API_KEY", "")
            resend.Emails.send({
                "from": "WolvCapital Support <support@mail.wolvcapital.com>",
                "to": ["support@wolvcapital.com", "admin@wolvcapital.com"],
                "subject": f"🚨 Human Support Requested — {user_name or user_email or session_id}",
                "html": f"""
                <h2>A user is requesting human support</h2>
                <p><strong>Name:</strong> {user_name or "Unknown"}</p>
                <p><strong>Email:</strong> {user_email or "Unknown"}</p>
                <p><strong>Session:</strong> {session_id}</p>
                <h3>Recent conversation:</h3>
                <pre style="background:#f4f4f4;padding:12px;border-radius:6px;">{transcript}</pre>
                <br>
                <a href="https://api.wolvcapital.com/admin/chat/chatsession/"
                   style="background:#2563eb;color:white;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:bold;">
                   View Chat Sessions
                </a>
                """,
            })
            session.alert_sent = True
            session.save()
        except Exception as e:
            print(f"Email alert failed: {e}")

    return JsonResponse({"status": "waiting", "message": "A human agent will join shortly."})


@csrf_exempt
def agent_reply(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=405)
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    session_id = str(payload.get("session_id", "")).strip()
    message = str(payload.get("message", "")).strip()

    if not session_id or not message:
        return JsonResponse({"error": "session_id and message required"}, status=400)

    from django.utils import timezone
    from .models import ChatSession
    ChatMessage.objects.create(
        session_id=session_id,
        role=ChatMessage.ASSISTANT,
        content=message,
        is_human_handover=True,
    )
    ChatSession.objects.filter(session_id=session_id).update(
        status="active",
        agent_joined_at=timezone.now(),
    )
    return JsonResponse({"status": "sent"})


def get_sessions(request):
    from .models import ChatSession
    sessions = ChatSession.objects.filter(
        status__in=["waiting", "active"]
    ).values("session_id", "user_email", "user_name", "status", "human_requested_at", "updated_at")
    return JsonResponse({"sessions": list(sessions)})


def get_messages(request, session_id):
    messages = ChatMessage.objects.filter(
        session_id=session_id
    ).values("role", "content", "is_human_handover", "created_at")
    return JsonResponse({"messages": list(messages)})


@csrf_exempt
@require_POST
def visitor_ping(request):
    """Called when a logged-in user enters the dashboard."""
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"ok": True})

    user_email = str(payload.get("user_email", "")).strip()
    user_name = str(payload.get("user_name", "")).strip()
    page = str(payload.get("page", "dashboard")).strip()

    try:
        resend.api_key = os.environ.get("RESEND_API_KEY", "")
        from django.utils import timezone
        resend.Emails.send({
            "from": "WolvCapital Support <support@mail.wolvcapital.com>",
            "to": ["admin@wolvcapital.com"],
            "subject": f"👤 User Online — {user_name or user_email}",
            "html": f"""
            <h2>A user just entered the dashboard</h2>
            <p><strong>Name:</strong> {user_name or "Unknown"}</p>
            <p><strong>Email:</strong> {user_email or "Unknown"}</p>
            <p><strong>Page:</strong> {page}</p>
            <p><strong>Time:</strong> {timezone.now().strftime("%Y-%m-%d %H:%M:%S UTC")}</p>
            <a href="https://api.wolvcapital.com/admin/chat/chatsession/"
               style="background:#2563eb;color:white;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:bold;">
               Open Support Inbox
            </a>
            """,
        })
    except Exception as e:
        print(f"Visitor ping email failed: {e}")

    return JsonResponse({"ok": True})


@csrf_exempt
def manage_session(request):
    """Close a session."""
    if request.method != "POST":
        from .models import ChatSession
        from django.utils import timezone
        sessions = ChatSession.objects.filter(
            status__in=["waiting", "active"]
        ).values("session_id", "user_email", "user_name", "status", "human_requested_at", "updated_at")
        return JsonResponse({"sessions": list(sessions)})
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON"}, status=400)
    action = payload.get("action")
    session_id = payload.get("session_id")
    if action == "close" and session_id:
        from .models import ChatSession
        from django.utils import timezone
        ChatSession.objects.filter(session_id=session_id).update(
            status="closed",
            closed_at=timezone.now()
        )
        return JsonResponse({"status": "closed"})
    return JsonResponse({"error": "Invalid action"}, status=400)
